import { JSDOM } from 'jsdom';
import {
    COLD_START_MAX_BINDING_BYTES,
    INNERTUBE_API_KEY,
    REQUEST_KEY,
    TV_CONFIG,
    TV_USER_AGENT,
    USER_AGENT,
    YT_BASE,
    WEB_CLIENT_NAME,
    WEB_CLIENT_VERSION
} from './src/utils/constants.js';
import { base64ToUint8, buildURL, parse_json, Uint8ToBase64 } from './src/utils/helpers.js';

function release_dom(dom) {
    if (!dom) return;

    if (globalThis.window === dom.window) {
        for (const property of ['window', 'document', 'location', 'origin', 'yt', 'navigator']) {
            try {
                delete globalThis[property];
            } catch {
                globalThis[property] = undefined;
            }
        }
    }

    dom.window.close();
}

function parse_waa_challenge(raw_data) {
    if (raw_data?.bgChallenge) return raw_data;

    if (raw_data?.[0]?.bgChallenge) return raw_data[0];

    let challenge_data;

    if (raw_data?.length > 1 && typeof raw_data[1] === 'string') {
        const bytes = base64ToUint8(raw_data[1]);
        challenge_data = JSON.parse(new TextDecoder().decode(bytes.map((value) => value + 97)));
    } else if (Array.isArray(raw_data?.[0])) {
        challenge_data = raw_data[0];
    } else if (Array.isArray(raw_data)) {
        challenge_data = raw_data;
    }

    if (!Array.isArray(challenge_data)) return;

    const [message_id, wrapped_script, wrapped_url, interpreter_hash, program, global_name] = challenge_data;
    const script = Array.isArray(wrapped_script)
        ? wrapped_script.find((value) => typeof value === 'string')
        : undefined;
    const interpreter_url = Array.isArray(wrapped_url)
        ? wrapped_url.find((value) => typeof value === 'string')
        : undefined;

    if (!program || !global_name || (!interpreter_url && !script)) return;

    return {
        bgChallenge: {
            messageId: message_id,
            program,
            globalName: global_name,
            interpreterHash: interpreter_hash,
            interpreterUrl: interpreter_url
                ? {
                      privateDoNotAccessOrElseTrustedResourceUrlWrappedValue: interpreter_url
                  }
                : undefined,
            interpreterJavascript: {
                privateDoNotAccessOrElseSafeScriptWrappedValue: script
            }
        }
    };
}

export async function create_bg(options) {
    const vm = options.globalObject[options.globalName];

    if (!vm || !vm.a) throw new Error('BotGuard VM unavailable');

    const vm_functions = Promise.withResolvers();

    const callback = (async_snapshot, shutdown, pass_event, check_camera) => {
        vm_functions.resolve({ async_snapshot, shutdown, pass_event, check_camera });
    };

    const sync_snapshot = await vm.a(
        options.program,
        callback,
        true,
        options.userInteractionElement,
        () => {},
        [[], []],
        undefined,
        false,
        []
    )?.[0];

    return {
        async snapshot(args, timeout = 3000) {
            const { async_snapshot } = await vm_functions.promise;

            return await new Promise((resolve, reject) => {
                const timer = setTimeout(() => reject(new Error('VM operation timed out')), timeout);

                async_snapshot(
                    (res) => {
                        clearTimeout(timer);
                        resolve(res);
                    },
                    [args.contentBinding, args.signedTimestamp, args.webPoSignalOutput, args.skipPrivacyBuffer]
                );
            });
        },
        async pass_event(args) {
            const { pass_event } = await vm_functions.promise;
            return pass_event?.(args);
        },
        async check_camera(args) {
            const { check_camera } = await vm_functions.promise;
            return check_camera?.(args);
        },
        async shutdown() {
            const { shutdown } = await vm_functions.promise;
            return shutdown?.();
        },
        async snapshot_synchronous(args) {
            if (!sync_snapshot) throw new Error('synchronous snapshot function not found');
            return sync_snapshot([
                args.contentBinding,
                args.signedTimestamp,
                args.webPoSignalOutput,
                args.skipPrivacyBuffer
            ]);
        }
    };
}

export class Minter {
    constructor(callback, client, dom, iTdata) {
        this.callback = callback;
        this.client = client;
        this.dom = dom;
        this.integrityTokenData = iTdata;
        this.expiresAt = iTdata?.expiresAt || 0;
        const threshold = Number(iTdata?.mint_refresh_threshold ?? iTdata?.mintRefreshThreshold);
        this.mintThreshold = Number.isFinite(threshold) && threshold > 0 ? threshold : 100;
        this.mintCount = 0;
        this.active = 0;
        this.retired = false;
        this.closed = false;
    }

    isExhausted() {
        return this.mintThreshold > 0 && this.mintCount >= this.mintThreshold;
    }

    static async create(integrityToken, webPoSignalOutput, client, dom) {
        const getMinter = webPoSignalOutput[0];

        if (!getMinter || !integrityToken?.integrity_token) throw new Error('Could not create WebPO minter');

        const callback = await getMinter(base64ToUint8(integrityToken?.integrity_token));

        if (!(callback instanceof Function)) throw new Error('WebPO minter unavailable');

        return new Minter(callback, client, dom, integrityToken);
    }

    retire() {
        this.retired = true;
        this.close_idles();
    }

    close_idles() {
        if (!this.retired || this.active > 0 || this.closed) return;

        this.closed = true;
        release_dom(this.dom);

        Promise.resolve(this.client?.shutdown?.()).catch(() => {});
    }

    async mintAsWebsafeString(contentBinding) {
        this.active++;
        this.mintCount++;

        try {
            return Uint8ToBase64(await this.callback(new TextEncoder().encode(contentBinding)), true);
        } finally {
            this.active--;
            this.close_idles();
        }
    }
}

let minter_promise;
let expires = 0;
let cur;

export async function getWebPo(useYouTubeAPI = true) {
    if (cur && cur.isExhausted()) {
        cur.retire();
        cur = undefined;
        minter_promise = undefined;
        expires = 0;
    }

    if (minter_promise && (expires === 0 || expires > Date.now() + 15000)) return minter_promise;

    cur?.retire();
    cur = undefined;
    minter_promise = undefined;

    let runtime_dom;

    minter_promise = (async () => {
        const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>', {
            url: YT_BASE,
            referrer: `${YT_BASE}/`,
            userAgent: USER_AGENT
        });

        runtime_dom = dom;
        Object.assign(globalThis, {
            window: dom.window,
            document: dom.window.document,
            location: dom.window.location,
            origin: dom.window.origin
        });

        Object.defineProperty(globalThis, 'navigator', {
            value: dom.window.navigator,
            configurable: true,
            writable: true
        });

        let key = REQUEST_KEY,
            challenge,
            eacrToken;

        try {
            const res = await fetch(YT_BASE, {
                headers: {
                    accept: '*/*',
                    'accept-language': 'en-US,en;q=0.7',
                    'user-agent': USER_AGENT
                }
            });

            const txt = await res.text();

            dom.window.yt = dom.window.yt || { config_: {} };
            dom.window.yt.config_ = dom.window.yt.config_ || {};

            const cfg = txt.matchAll(/ytcfg\.set\(({.+?})\);/gs);

            for (const match of cfg) {
                try {
                    Object.assign(dom.window.yt.config_, JSON.parse(match[1]));
                } catch {
                    try {
                        Object.assign(dom.window.yt.config_, parse_json(match[1]));
                    } catch {}
                }
            }

            const reg_match = txt.matchAll(
                /ytcfg\.set\(["']([A-Za-z0-9_]+)["']\s*,\s*(["'].*?["']|true|false|\d+|{[^}]+}|\[[^\]]+\])\);/gs
            );

            for (const match of reg_match) {
                try {
                    dom.window.yt.config_[match[1]] = JSON.parse(match[2]);
                } catch {
                    dom.window.yt.config_[match[1]] = match[2].replace(/^["']|["']$/g, '');
                }
            }

            if (!dom.window.yt.config_.EVENT_ID) {
                const event_reg = txt.match(/"EVENT_ID"\s*:\s*"([^"]+)"/);
                if (event_reg) {
                    dom.window.yt.config_.EVENT_ID = event_reg[1];
                }
            }

            globalThis.yt = dom.window.yt;

            const attestation = txt.match(/window\.ytAtN\(\s*({[\s\S]*?})\s*\)/);

            if (attestation) {
                try {
                    const parsed = parse_json(attestation[1]);
                    challenge = parsed.R?.bgChallenge ? parsed.R : parse_waa_challenge(parsed.R);
                    eacrToken = parsed.T;
                } catch {
                    challenge = undefined;
                }
            }

            //console.log(eacrToken)

            if (!challenge?.bgChallenge && !eacrToken) {
                const initialAttestationMatch = txt.match(/initialAttestationDataJson\s*=\s*({[\s\S]*?});/);

                if (initialAttestationMatch) {
                    try {
                        const parsed = parse_json(initialAttestationMatch[1]);
                        challenge = parsed.R?.bgChallenge ? parsed.R : parse_waa_challenge(parsed.R);
                        eacrToken = parsed.T || eacrToken;
                    } catch {}
                }
            }
        } catch {}

        if (!challenge?.bgChallenge) {
            try {
                const payload = {
                    context: {
                        client: {
                            clientName: WEB_CLIENT_NAME,
                            clientVersion: WEB_CLIENT_VERSION
                        }
                    },
                    engagementType: 'ENGAGEMENT_TYPE_UNBOUND'
                };

                if (eacrToken) payload.eacrToken = eacrToken;

                const att_res = await fetch(`${YT_BASE}/youtubei/v1/att/get?prettyPrint=false`, {
                    method: 'POST',
                    headers: {
                        accept: '*/*',
                        'content-type': 'application/json',
                        'user-agent': USER_AGENT,
                        'x-goog-api-key': INNERTUBE_API_KEY
                    },
                    body: JSON.stringify(payload)
                });

                if (!att_res.ok) throw new Error(`att/get returned ${att_res.status}`);

                const attestation = await att_res.json();

                if (!attestation?.bgChallenge) throw new Error('could not get challenge from att/get');

                challenge = { bgChallenge: attestation.bgChallenge };
            } catch {
                challenge = undefined;
            }
        }

        if (!challenge?.bgChallenge) {
            const waa_res = await fetch(buildURL('Create', false), {
                method: 'POST',
                headers: {
                    'content-type': 'application/json+protobuf',
                    'x-goog-api-key': INNERTUBE_API_KEY,
                    'x-user-agent': 'grpc-web-javascript/0.1',
                    'user-agent': USER_AGENT
                },
                body: JSON.stringify([key])
            });

            if (!waa_res.ok) throw new Error(`WAA Create returned ${waa_res.status}`);

            challenge = parse_waa_challenge(await waa_res.json());
        }

        if (!challenge?.bgChallenge) {
            try {
                const res = await fetch(TV_CONFIG, { headers: { accept: '*/*', 'user-agent': TV_USER_AGENT } });
                const txt = await res.text();

                if (!txt.startsWith(')]}')) throw new Error('invalid yt tv config response');

                const json = JSON.parse(txt.slice(4));

                challenge = json.challengeParams?.R ? JSON.parse(json.challengeParams.R) : undefined;
                key = json.challengeRequestKey || key;
            } catch {
                challenge = undefined;
            }
        }

        if (!challenge?.bgChallenge) throw new Error('Could not get botguard challenge');

        const interpreterUrl =
            challenge.bgChallenge.interpreterUrl?.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue;
        //console.log(interpreterUrl)
        const inlineInterpreter =
            challenge.bgChallenge.interpreterJavascript?.privateDoNotAccessOrElseSafeScriptWrappedValue;
        const interpreter =
            inlineInterpreter || (interpreterUrl ? await (await fetch(`https:${interpreterUrl}`)).text() : '');

        if (!interpreter) throw new Error("couldn't load botguard interpreter");

        //console.log(challenge.bgChallenge);

        new Function(interpreter)();

        const client = await create_bg({
            program: challenge.bgChallenge.program,
            globalName: challenge.bgChallenge.globalName,
            globalObject: globalThis
        });

        const signals = [];
        const res = await client.snapshot({ webPoSignalOutput: signals });
        const endpoint = buildURL('GenerateIT', useYouTubeAPI);

        const generate_options = (request_key) => ({
            method: 'POST',
            headers: {
                'content-type': 'application/json+protobuf',
                'x-goog-api-key': request_key,
                'x-user-agent': 'grpc-web-javascript/0.1',
                'user-agent': USER_AGENT
            },
            body: JSON.stringify([key, res])
        });

        let t_txt = await fetch(endpoint, generate_options(INNERTUBE_API_KEY));

        if (!t_txt.ok) throw new Error(`GenerateIT returned ${t_txt.status}`);

        const [integrity_token, estimated_ttl_secs, mint_refresh_threshold, websafe_fallback_token] =
            await t_txt.json();
        const ttl = Number(estimated_ttl_secs);

        expires = Date.now() + Math.max(1, (Number.isFinite(ttl) && ttl > 0 ? ttl : 300) - 30) * 1000;

        const minter = await Minter.create(
            {
                integrity_token,
                mint_refresh_threshold,
                websafe_fallback_token,
                expiresAt: expires
            },
            signals,
            client,
            dom
        );
        minter.expiresAt = expires;

        cur = minter;

        return minter;
    })();
    try {
        return await minter_promise;
    } catch (error) {
        release_dom(runtime_dom);
        minter_promise = undefined;
        expires = 0;
        throw error;
    }
}

export async function fetch_pot(contentBinding, useYouTubeAPI = true, ttl = null) {
    const minter = await getWebPo(useYouTubeAPI);
    const minter_expires = minter.expiresAt || expires;
    const token_expires = Number.isFinite(ttl) && ttl > 0 ? Math.min(minter_expires, Date.now() + ttl) : minter_expires;

    return {
        poToken: await minter.mintAsWebsafeString(contentBinding),
        contentBinding,
        ttl: Math.max(0, Math.floor((token_expires - Date.now()) / 1000)),
        minterSession: minter.integrityTokenData?.integrity_token || null
    };
}

// this token only bridges the short period before yt moves sps from 2 to 3
// its generated per response cuz it contains the current time
export function createColdStartToken(contentBinding, clientState = 1) {
    const bytecode = new TextEncoder().encode(contentBinding);

    if (bytecode.length > COLD_START_MAX_BINDING_BYTES) return;

    const timestamp = Math.floor(Date.now() / 1000);
    const rand_keys = [Math.floor(Math.random() * 256), Math.floor(Math.random() * 256)];

    const header = rand_keys.concat(
        [0, clientState],
        [(timestamp >> 24) & 0xff, (timestamp >> 16) & 0xff, (timestamp >> 8) & 0xff, timestamp & 0xff]
    );

    const packet = new Uint8Array(2 + header.length + bytecode.length);

    packet[0] = 34;
    packet[1] = header.length + bytecode.length;
    packet.set(header, 2);
    packet.set(bytecode, 2 + header.length);

    const payload = packet.subarray(2);

    for (let i = 2; i < payload.length; i++) payload[i] = payload[i] ^ payload[i % 2];

    return Uint8ToBase64(packet, true);
}

export function decodeColdStartToken(token) {
    const packet = base64ToUint8(token);

    if (packet.length < 10 || packet[0] !== 34) throw new Error('invalid cold start token');

    const length = packet[1];
    if (packet.length !== length + 2 || length < 8) throw new Error('invalid cold start packet length');

    const payload = packet.slice(2);
    for (let i = 2; i < payload.length; i++) payload[i] = payload[i] ^ payload[i % 2];

    const timestamp = ((payload[4] << 24) | (payload[5] << 16) | (payload[6] << 8) | payload[7]) >>> 0;

    return {
        contentBinding: new TextDecoder().decode(payload.subarray(8)),
        timestamp,
        unknownVal: payload[2],
        clientState: payload[3],
        keys: [payload[0], payload[1]],
        date: new Date(timestamp * 1000)
    };
}
